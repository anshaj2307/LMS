module.exports = {
    MONGO_URI:
        "mongodb+srv://mahen:12345a@cluster0.zxtfp.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
    JWT_SECRET: "MOHENMONDALJDFKFLL",
};