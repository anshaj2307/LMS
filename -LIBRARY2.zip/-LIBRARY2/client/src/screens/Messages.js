import React from 'react';

const Messages = () => {
    return (
        <div className="col-md-9 m-auto">
            <br />
            <br />
            <h3 className="text-center bg-success p-2">No Message is Here </h3>
        </div>
    );
};

export default Messages;
